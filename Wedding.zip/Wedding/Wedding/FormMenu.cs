﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wedding
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        public void panel(Form frm)
        {
            this.ContainPanel.Controls.Clear();
            frm.TopLevel = false;
            frm.AutoScroll = true;
            this.ContainPanel.Controls.Add(frm);
            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.Show();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            lbname.Text = "កម្មវិធីកត់ចំណង់ដៃ";
        }

        private void btnGuest_Click(object sender, EventArgs e)
        {
            lbname.Text = "ព័ត៌មានរបស់ភ្ញៀវ";
            FormGuest Guest = new FormGuest();
            panel(Guest);
        }

        private void btnMoney_Click(object sender, EventArgs e)
        {
            lbname.Text = "ចំណង់ដៃរបស់ភ្ញៀវ"; //របាយការណ៍
            FormMoney Money = new FormMoney();
            panel(Money);
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            lbname.Text = "របាយការណ៍ចំណង់ដៃ";
            FormReportMoney report = new FormReportMoney();
            panel(report);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult x;
            x = MessageBox.Show("Are You Sure?","Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (x == DialogResult.No)
                return;
            Application.Exit();
        }
    }
}
