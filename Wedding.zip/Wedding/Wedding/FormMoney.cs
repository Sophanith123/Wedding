﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.Threading;

namespace Wedding
{
    public partial class FormMoney : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Wedding.accdb; Persist Security Info=False;");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        string sql = ""; int dataid; //string tempid;
        FormGuest guest = new FormGuest(); double ttdollar, ttrail, alltotald, /*alltotalr*/ exchange; int checkboxcheck;

        public FormMoney()
        {
            InitializeComponent();
        }

        private void FormMoney_Load(object sender, EventArgs e)
        {
            txtID.Enabled = false; txtName.Enabled = false;
            txtID.Text = ""; txtName.Text = ""; txtRail.Text = ""; txtDollar.Text = ""; txtOther.Text = ""; cboPaid.Text="";
            txtTotalDollar.Text = ""; txtTotalRail.Text = "";
            sql = "Select GuestID, GuestName From tbGuest where Paid=" + 0;
            guest.ListDisplayView(sql, LstGuest);
            txtSearchStaff.Focus();
            btnSave.Enabled = false;
            sql = "Select MoneyID From tbMoney";
            guest.selectLastRecord(sql, "MoneyID");
            dataid = guest.dataid;
            checkBox1.Checked = false;
        }

        private void btnAddNewGuest_Click(object sender, EventArgs e)
        {
            FormGuest g = new FormGuest();
            g.ShowDialog();
        }

        private void LstGuest_Click(object sender, EventArgs e)
        {
            txtID.Text = ""; txtName.Text = ""; txtRail.Text = ""; txtDollar.Text = ""; txtOther.Text = ""; cboPaid.Text = "";
            txtTotalDollar.Text = ""; txtTotalRail.Text = "";
            string dara;
            txtDollar.Focus();
            btnSave.Enabled = true;
            if (LstGuest.Items.Count == 0)
                return;
            dara = LstGuest.SelectedValue.ToString();
            var cultureInfo = Thread.CurrentThread.CurrentCulture;
            var numberFormatInfo = (NumberFormatInfo)cultureInfo.NumberFormat.Clone();
            string id = ""; string bname = ""; string name = "";
            string paid = ""; string mdollar = ""; string mrail = "";
            string m_other = ""; string m_tdollar = "";
            try
            {
                con.Open();
                if (checkBox1.Checked == false)
                {
                    cboPaid.Enabled = true;
                    sql = "Select * from tbGuest where GuestID=" + dara + "and Paid=" + 0;
                    cmd = new OleDbCommand(sql, con);
                    dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        id = dr["GuestID"].ToString();
                        bname = dr["BName"].ToString();
                        name = dr["GuestName"].ToString();
                        paid = dr["Paid"].ToString();

                        //if (paid == "False")
                        //    paid = "មិនពិត";
                        //else
                        //    paid = "ពិត";
                    }
                    txtID.Text = id;
                    txtName.Text = bname + " " + name;
                    cboPaid.Text = paid;
                    cboPaid.Text = "ពិត";
                }
                else
                {
                    cboPaid.Enabled = false;
                    sql = "SELECT tbGuest.GuestID, tbGuest.BName,tbGuest.GuestName, tbGuest.Paid, tbMoney.GuestID, tbMoney.Dollar, tbMoney.Rail, tbMoney.Other, tbMoney.TotalDollar" +
                        " FROM tbMoney INNER JOIN tbGuest ON tbMoney.GuestID = tbGuest.GuestID where tbMoney.GuestID=" + dara;
                    cmd = new OleDbCommand(sql, con);
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        id = dr["tbGuest.GuestID"].ToString();
                        bname = dr["BName"].ToString();
                        name = dr["GuestName"].ToString();
                        paid = dr["Paid"].ToString();

                        mdollar = dr["Dollar"].ToString();
                        mrail = dr["Rail"].ToString();
                        m_other = dr["Other"].ToString();
                        m_tdollar = dr["TotalDollar"].ToString();
                    }
                    txtID.Text = id;
                    txtName.Text = bname + " " + name;
                    if (paid == "False")
                        paid = "មិនពិត";
                    else
                        paid = "ពិត";
                    cboPaid.Text = paid;

                    txtDollar.Text = mdollar;
                    double u = double.Parse(txtDollar.Text);
                    string x = String.Format("{0:C}", u);
                    txtDollar.Text = x;
                    
                    numberFormatInfo.CurrencySymbol = "៛";
                    txtRail.Text = mrail;
                    u = double.Parse(txtRail.Text);
                    x = u.ToString("C", numberFormatInfo);
                    txtRail.Text = x;

                    txtOther.Text = m_other;

                    txtTotalDollar.Text = m_tdollar;
                    u = double.Parse(txtTotalDollar.Text);
                    x = String.Format("{0:C}", u);
                    txtTotalDollar.Text = x;

                    double temprail = double.Parse(m_tdollar);
                    double temptotalrail = temprail * 4000;
                    numberFormatInfo.CurrencySymbol = "៛";
                    txtTotalRail.Text = temptotalrail.ToString();
                    u = double.Parse(txtTotalRail.Text);
                    x = u.ToString("C", numberFormatInfo);
                    txtTotalRail.Text = x;
                }
                con.Close();

                txtTotalDollar.ReadOnly = true;
                txtTotalRail.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMoney_Load(sender, e);
        }

        private void txtSearchStaff_TextChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                sql = "Select * From tbGuest Where GuestName like '%" + txtSearchStaff.Text + "%' and Paid=" + -1;
                guest.ListDisplayView(sql, LstGuest);
            }
            else
            {
                sql = "Select * From tbGuest Where GuestName like '%" + txtSearchStaff.Text + "%' and Paid=" + 0;
                guest.ListDisplayView(sql, LstGuest);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                checkboxcheck = 0;
                btnSave.Text = "កែរប្រែ";
                //cboPaid.Enabled = true;
                sql = "Select GuestID, GuestName From tbGuest where Paid=" + -1;
                guest.ListDisplayView(sql, LstGuest);
            }
            else
            {
                checkboxcheck = 1;
                btnSave.Text = "រក្សាទុក";
                //cboPaid.Enabled = false;
                sql = "Select GuestID, GuestName From tbGuest where Paid=" + 0;
                guest.ListDisplayView(sql, LstGuest);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtOther.Text == "")
                txtOther.Text = "N/A";
            if (txtDollar.Text == "")
                txtDollar.Text = "0.00";
            if (txtRail.Text == "")
                txtRail.Text = "0.00";
            int paid;
            if (cboPaid.Text == "មិនពិត")
                paid = 0;
            else
                paid = -1;

            //cut string
            string strta = txtDollar.Text;
            int m = strta.Length;
            double dollar = double.Parse(strta.Substring(1, m - 1));

            strta = txtRail.Text;
            m = strta.Length;
            double rail = double.Parse(strta.Substring(1, m - 1));

            alltotald = ttdollar + exchange;

            string guestid = "'" + txtID.Text + "'";
            string other = "'" + txtOther.Text + "'";
            //double dollar = double.Parse(txtDollar.Text);
            //double rail = double.Parse(txtRail.Text);
            //double totaldollar = double.Parse(txtTotalDollar.Text);

            try
            {
                con.Open();
                if (btnSave.Text == "រក្សាទុក")
                {
                    sql = "Insert Into tbMoney (MoneyID, GuestID, Dollar, Rail, Other, TotalDollar) Values(" + dataid + "," + guestid + "," + dollar + "," + rail + ", " + other + ", " + alltotald + ")";
                    cmd = new OleDbCommand(sql, con);
                    cmd.ExecuteNonQuery();

                    sql = "Update tbGuest Set Paid = " + paid + " where GuestID=" + txtID.Text;
                    cmd = new OleDbCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Saved.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    sql = "Update tbMoney Set Dollar = " + dollar + ",Rail = " + rail + ",Other = " + other + ",TotalDollar = " + alltotald + " where GuestID=" + txtID.Text;
                    cmd = new OleDbCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Changed.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
            }
            FormMoney_Load(sender, e);
        }

        private void txtDollar_Leave(object sender, EventArgs e)
        {
            if (checkboxcheck == 0 || txtDollar.Text == "")
                return;
            double u = double.Parse(txtDollar.Text);
            ttdollar = u;
            string x = String.Format("{0:C}", u);
            txtDollar.Text = x;
        }

        private void txtRail_Leave(object sender, EventArgs e)
        {
            if (checkboxcheck == 0 || txtRail.Text == "")
                return;
            var cultureInfo = Thread.CurrentThread.CurrentCulture;
            var numberFormatInfo = (NumberFormatInfo)cultureInfo.NumberFormat.Clone();
            numberFormatInfo.CurrencySymbol = "៛";

            double u = double.Parse(txtRail.Text);
            ttrail = u; exchange = ttrail / 4000;
            string x = u.ToString("C", numberFormatInfo);
            txtRail.Text = x;
        }
    }
}
