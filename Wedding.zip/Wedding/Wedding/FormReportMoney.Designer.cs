﻿namespace Wedding
{
    partial class FormReportMoney
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormReportMoney));
            this.LVReportMoney = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPreview = new System.Windows.Forms.Button();
            this.txtSearchGuest = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDollar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtallTotalR = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtallTotaldollar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LVReportMoney
            // 
            this.LVReportMoney.Font = new System.Drawing.Font("Khmer OS Battambang", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVReportMoney.Location = new System.Drawing.Point(12, 110);
            this.LVReportMoney.Name = "LVReportMoney";
            this.LVReportMoney.Size = new System.Drawing.Size(1054, 271);
            this.LVReportMoney.TabIndex = 0;
            this.LVReportMoney.UseCompatibleStateImageBehavior = false;
            this.LVReportMoney.View = System.Windows.Forms.View.List;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Khmer OS Siemreap", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(405, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 52);
            this.label1.TabIndex = 1;
            this.label1.Text = "ចំណង់ដៃពិធីមង្គលការ";
            // 
            // btnPreview
            // 
            this.btnPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreview.Location = new System.Drawing.Point(939, 67);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(109, 37);
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // txtSearchGuest
            // 
            this.txtSearchGuest.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchGuest.Location = new System.Drawing.Point(104, 70);
            this.txtSearchGuest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSearchGuest.Name = "txtSearchGuest";
            this.txtSearchGuest.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSearchGuest.Size = new System.Drawing.Size(246, 35);
            this.txtSearchGuest.TabIndex = 11;
            this.txtSearchGuest.Tag = "*";
            this.txtSearchGuest.TextChanged += new System.EventHandler(this.txtSearchGuest_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 73);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(86, 27);
            this.label2.TabIndex = 10;
            this.label2.Text = "ស្វែងរកភ្ញៀវ:";
            // 
            // txtRail
            // 
            this.txtRail.Font = new System.Drawing.Font("Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRail.Location = new System.Drawing.Point(849, 387);
            this.txtRail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtRail.Name = "txtRail";
            this.txtRail.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRail.Size = new System.Drawing.Size(217, 31);
            this.txtRail.TabIndex = 62;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(737, 387);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(106, 27);
            this.label6.TabIndex = 63;
            this.label6.Text = "សរុបប្រាក់រៀល:";
            // 
            // txtDollar
            // 
            this.txtDollar.Font = new System.Drawing.Font("Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDollar.Location = new System.Drawing.Point(467, 387);
            this.txtDollar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDollar.Name = "txtDollar";
            this.txtDollar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtDollar.Size = new System.Drawing.Size(217, 31);
            this.txtDollar.TabIndex = 61;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(356, 387);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(105, 27);
            this.label5.TabIndex = 60;
            this.label5.Text = "សរុបប្រាក់ដុល្លា:";
            // 
            // txtallTotalR
            // 
            this.txtallTotalR.Font = new System.Drawing.Font("Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtallTotalR.Location = new System.Drawing.Point(849, 426);
            this.txtallTotalR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtallTotalR.Name = "txtallTotalR";
            this.txtallTotalR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtallTotalR.Size = new System.Drawing.Size(217, 31);
            this.txtallTotalR.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(697, 426);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(146, 27);
            this.label3.TabIndex = 67;
            this.label3.Text = "ចំនួនប្រាក់សរុបគិតជា៛:";
            // 
            // txtallTotaldollar
            // 
            this.txtallTotaldollar.Font = new System.Drawing.Font("Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtallTotaldollar.Location = new System.Drawing.Point(467, 426);
            this.txtallTotaldollar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtallTotaldollar.Name = "txtallTotaldollar";
            this.txtallTotaldollar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtallTotaldollar.Size = new System.Drawing.Size(217, 31);
            this.txtallTotaldollar.TabIndex = 65;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Khmer OS Siemreap", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(312, 426);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(149, 27);
            this.label4.TabIndex = 64;
            this.label4.Text = "ចំនួនប្រាក់សរុបគិតជា$:";
            // 
            // FormReportMoney
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 496);
            this.Controls.Add(this.txtallTotalR);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtallTotaldollar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtRail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDollar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSearchGuest);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LVReportMoney);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormReportMoney";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormReportMoney";
            this.Load += new System.EventHandler(this.FormReportMoney_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView LVReportMoney;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.TextBox txtSearchGuest;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDollar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtallTotalR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtallTotaldollar;
        private System.Windows.Forms.Label label4;
    }
}