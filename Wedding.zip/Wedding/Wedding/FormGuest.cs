﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Wedding
{
    public partial class FormGuest : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Wedding.accdb; Persist Security Info=False;");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null;
        string sql = ""; public int dataid; public string tempid; string name, listid; int check;

        public FormGuest()
        {
            InitializeComponent();
        }

        public void selectLastRecord(string sql, string ID)
        {
            try
            {
                con.Open();
                //sql = "Select * from tbGuest";
                cmd = new OleDbCommand(sql, con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    tempid = dr[ID].ToString();
                }
                con.Close();
                int num;
                if (tempid == null)
                {
                    dataid = 1;
                }
                else
                {
                    num = Int16.Parse(tempid);
                    dataid = num + 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
            }
        }

        public void ListDisplayView(string sql, ListBox lst)
        {
            try
            {
                DataTable table = new DataTable();
                table.Columns.Add("ID", typeof(string));
                table.Columns.Add("Name", typeof(string));

                con.Open();
                cmd = new OleDbCommand(sql, con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    listid = dr["GuestID"].ToString();
                    name = dr["GuestName"].ToString();

                    table.Rows.Add(listid, name);
                }
                con.Close();

                lst.DisplayMember = "Name";
                lst.ValueMember = "ID";
                lst.DataSource = table;        
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
            }
        }

        private void FormGuest_Load(object sender, EventArgs e)
        {
            txtID.Enabled = false;
            btnSave.Enabled = false;
            sql = "Select GuestID, GuestName From tbGuest";
            ListDisplayView(sql, LstGuest);
            sql = "Select * from tbGuest";
            selectLastRecord(sql, "GuestId");
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            check = 1;
            txtID.Text = "លេខស្វ័យប្រវត្តិ";
            cbobname.Text = "";
            txtName.Text = "";
            cboPaid.Text = "មិនពិត";
            cbobname.Focus();
            btnSave.Text = "រក្សាទុក";
            btnSave.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cbobname.Text == "")
            {
                MessageBox.Show("Please! Input Information", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cbobname.Focus();
                return;
            }
            if (txtName.Text == "")
            {
                MessageBox.Show("Please! Input Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            string bna = "'" + cbobname.Text + "'";
            string na = "'" + txtName.Text + "'";
            int paid;
            if (cboPaid.Text == "មិនពិត")
                paid = 0;
            else
                paid = 1;
            try
            {
                con.Open();
                if (check == 1)
                {
                    sql = "Insert Into tbGuest Values(" + dataid + "," + bna + "," + na + ", " + paid + ")";
                    cmd = new OleDbCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Saved.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    sql = "Update tbGuest Set BName = " + bna + ", GuestName = " + na + ", Paid = " + paid + " where GuestID=" + txtID.Text;
                    cmd = new OleDbCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Edited.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
                return;
            }
            FormGuest_Load(sender, e);
        }

        private void LstGuest_Click(object sender, EventArgs e)
        {
            check = 0;
            if (LstGuest.Items.Count == 0)
                return;
            btnSave.Enabled = true;
            btnSave.Text = "កែប្រែ";
            string dara = LstGuest.SelectedValue.ToString();
            string id="";
            string bname = "";
            string name = "";
            string paid = "";
            try
            {
                con.Open();
                sql = "Select * from tbGuest where GuestID=" + dara;
                cmd = new OleDbCommand(sql, con);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    id = dr["GuestID"].ToString();
                    bname = dr["BName"].ToString();
                    name = dr["GuestName"].ToString();
                    paid = dr["Paid"].ToString();

                    if (paid == "False")
                        paid = "មិនពិត";
                    else
                        paid = "ពិត";
                }
                con.Close();
                txtID.Text = id;
                cbobname.Text = bname;
                txtName.Text = name;
                cboPaid.Text = paid;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Commit Exception Type: " + ex.GetType());
                MessageBox.Show("Message:  " + ex.Message);
            }
        }

        private void txtSearchStaff_TextChanged(object sender, EventArgs e)
        {
            sql = "Select * From tbGuest Where GuestName like '%" + txtSearchStaff.Text + "%' ";
            ListDisplayView(sql, LstGuest);
        }

        private void LstGuest_SelectedIndexChanged(object sender, EventArgs e)
        {
            //LstGuest_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
