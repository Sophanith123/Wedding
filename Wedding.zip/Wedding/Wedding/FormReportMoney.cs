﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Globalization;
using System.Threading;

namespace Wedding
{
    public partial class FormReportMoney : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Wedding.accdb; Persist Security Info=False;");
        OleDbCommand cmd = null;
        OleDbDataReader dr = null; double totalkitjeadollar, totaldollar;
        string sql; int no;

        public FormReportMoney()
        {
            InitializeComponent();
        }

        public void headerListView(string hrd, ListView Lv)
        {
            string colName;
            int w;
            Lv.Columns.Clear();
            string[] col = hrd.Split('|');
            foreach (string str in col)
            {
                string[] colHead = str.Split(';');
                colName = colHead[0];
                w = Int16.Parse(colHead[1]);
                Lv.Columns.Add(colName, w);
            }
            Lv.View = View.Details;
            Lv.GridLines = true;
            Lv.FullRowSelect = true;
            //Lv.Font = new System.Drawing.Font(Lv.Font.FontFamily, 12);
            Lv.Font = new Font("Khmer OS Siemreap", 11, FontStyle.Regular);
        }

        public void addItemListView(ListView LV, params string[] data)
        {
            ListViewItem item = new ListViewItem(data);
            LV.Items.Add(item);
        }

        private void commend(string sql)
        {
            totalkitjeadollar = 0; totaldollar = 0;
            var cultureInfo = Thread.CurrentThread.CurrentCulture;
            var numberFormatInfo = (NumberFormatInfo)cultureInfo.NumberFormat.Clone();
            numberFormatInfo.CurrencySymbol = "៛";

            string id = ""; string bname = ""; string name = ""; string paid = "";
            string mdollar = ""; string mrail = ""; string m_other = ""; string m_tdollar = "";
            string xx = ""; string xxx = "";
            con.Open();
            cmd = new OleDbCommand(sql, con);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                id = dr["tbGuest.GuestID"].ToString();
                bname = dr["BName"].ToString();
                name = dr["GuestName"].ToString();
                paid = dr["Paid"].ToString();

                mdollar = dr["Dollar"].ToString();
                mrail = dr["Rail"].ToString();
                m_other = dr["Other"].ToString();
                m_tdollar = dr["TotalDollar"].ToString();

                string shname = bname + " " + name;
                double u = double.Parse(mdollar);
                totaldollar = totaldollar + u;
                string x = String.Format("{0:C}", u);
                xx = String.Format("{0:C}", totaldollar);
                string shdollar = x;


                u = double.Parse(mrail);
                x = u.ToString("C", numberFormatInfo);
                string shrail = x;

                u = double.Parse(m_tdollar);
                totalkitjeadollar = totalkitjeadollar + u;
                x = String.Format("{0:C}", u);
                xxx = String.Format("{0:C}", totalkitjeadollar);
                string shtotaldollar = x;

                double temprail = double.Parse(m_tdollar);
                double temptotalrail = temprail * 4000;
                numberFormatInfo.CurrencySymbol = "៛";
                string shtotalrail = temptotalrail.ToString();
                u = double.Parse(shtotalrail);
                x = u.ToString("C", numberFormatInfo);
                shtotalrail = x;

                addItemListView(LVReportMoney, shname, shdollar, shrail, m_other, shtotaldollar, shtotalrail);
            }
            con.Close();
            txtDollar.Text = xx; 
            txtRail.Text = (totaldollar * 4000).ToString();
            double uu = double.Parse(txtRail.Text);
            string zz = uu.ToString("C", numberFormatInfo);
            txtRail.Text = zz;

            txtallTotaldollar.Text = xxx; 
            txtallTotalR.Text = (totalkitjeadollar * 4000).ToString();
            uu = double.Parse(txtallTotalR.Text);
            zz = uu.ToString("C", numberFormatInfo);
            txtallTotalR.Text = zz;
        }

        private void FormReportMoney_Load(object sender, EventArgs e)
        {
            LVReportMoney.Items.Clear();
            headerListView("ឈ្មោះភ្ញៀវ;200|ប្រាក់ដុល្លា($);155|ប្រាក់រៀល(៛);175|ផ្សេងទៀត;150|សរុប($);170|សរុប(៛);195", LVReportMoney);            
            sql = "SELECT tbGuest.GuestID, tbGuest.BName,tbGuest.GuestName, tbGuest.Paid, tbMoney.GuestID, tbMoney.Dollar, tbMoney.Rail, tbMoney.Other, tbMoney.TotalDollar" +
                        " FROM tbMoney INNER JOIN tbGuest ON tbMoney.GuestID = tbGuest.GuestID";
            commend(sql);
        }

        private void txtSearchGuest_TextChanged(object sender, EventArgs e)
        {
            LVReportMoney.Items.Clear();
            sql = "SELECT tbGuest.GuestID, tbGuest.BName,tbGuest.GuestName, tbGuest.Paid, tbMoney.GuestID, "
                    + "tbMoney.Dollar, tbMoney.Rail, tbMoney.Other, tbMoney.TotalDollar"
                    + " FROM tbMoney INNER JOIN tbGuest ON tbMoney.GuestID = tbGuest.GuestID Where tbGuest.BName like '%" + txtSearchGuest.Text + "%'"
                    + " or tbGuest.GuestName like '%" + txtSearchGuest.Text + "%' ";
            //sql = "SELECT tbGuest.GuestID, tbGuest.BName,tbGuest.GuestName, tbGuest.Paid, tbMoney.GuestID, "
            //        + "tbMoney.Dollar, tbMoney.Rail, tbMoney.Other, tbMoney.TotalDollar"
            //        + " FROM tbMoney INNER JOIN tbGuest ON tbMoney.GuestID = tbGuest.GuestID Where tbGuest.GuestName like '%" + txtSearchGuest.Text + "%'";
            commend(sql);
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            FormMoney f = new FormMoney();
            f.ShowDialog();
        }
    }
}
