﻿namespace Wedding {
    
    
    public partial class dsWedding {
    }
}
namespace Wedding {
    
    
    public partial class dsWedding {
    }
}
